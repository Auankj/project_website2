# Ultrasonic_radar
The first file is the Arduino sketch
The second file contains the code for Processing IDE 
